// ─────────────────────────────────────────────────────────────────────────────
// detection/correlation-engine/correlation.service.ts
//
// Correlation Engine — detects complex attack patterns from rule combinations.
//
// A pattern fires when ALL its required rules are triggered simultaneously.
// Pattern detection significantly boosts the final risk score because
// multiple corroborating signals reduce false-positive risk.
//
// Patterns are defined declaratively (support YAML-like structure) so they
// can be updated without code changes.
// ─────────────────────────────────────────────────────────────────────────────

import { Injectable, Logger } from '@nestjs/common';
import { DetectionContext, CorrelationResult } from '../rule-engine/detection-context';

// ─── Attack Pattern Definition ────────────────────────────────────────────────
export interface AttackPattern {
  id:           string;
  name:         string;
  description:  string;
  // ALL of these rules must be triggered
  requiredRules: string[];
  // AT LEAST ONE of these additional rules (optional amplifier)
  optionalRules?: string[];
  // Score bonus applied to phishingScore when pattern matches
  bonusScore:   number;
  // Severity classification
  severity:     'critical' | 'high' | 'medium';
}

@Injectable()
export class CorrelationService {
  private readonly logger = new Logger(CorrelationService.name);

  // ─── Attack Pattern Library ────────────────────────────────────────────────
  // Patterns can be loaded from YAML in a future iteration (infrastructureRules
  // stub supports this). For now, defined programmatically.
  private readonly patterns: AttackPattern[] = [
    // ── BEC (Business Email Compromise) ──────────────────────────────────────
    {
      id:           'bec_attack',
      name:         'Business Email Compromise',
      description:  'Impersonation of executive combined with financial pressure tactics',
      requiredRules: ['display_name_impersonation', 'bec_language_detected'],
      optionalRules: ['first_contact_sender_risk', 'reply_to_domain_mismatch'],
      bonusScore:   30,
      severity:     'critical',
    },

    // ── Phishing Campaign ─────────────────────────────────────────────────────
    {
      id:           'phishing_campaign',
      name:         'Phishing Campaign',
      description:  'New domain with urgent language and credential harvesting',
      requiredRules: ['urgent_phishing_language', 'credential_harvesting_attempt'],
      optionalRules: ['newly_registered_domain', 'html_obfuscation_phishing', 'ip_based_url'],
      bonusScore:   25,
      severity:     'critical',
    },

    // ── Brand Spoofing Attack ─────────────────────────────────────────────────
    {
      id:           'brand_spoofing_attack',
      name:         'Brand Spoofing / Impersonation',
      description:  'Domain lookalike or homoglyph combined with brand abuse in body',
      requiredRules: ['brand_abuse_in_body'],
      optionalRules: ['typosquatting_domain', 'homoglyph_domain_spoofing', 'lookalike_domain_attack', 'sender_display_name_mismatch'],
      bonusScore:   20,
      severity:     'high',
    },

    // ── Auth Bypass Spoofing ──────────────────────────────────────────────────
    {
      id:           'auth_bypass_spoofing',
      name:         'Authentication Bypass Spoofing',
      description:  'Email auth failure combined with display name spoofing',
      requiredRules: ['email_auth_failure', 'sender_display_name_mismatch'],
      optionalRules: ['display_name_impersonation', 'reply_to_domain_mismatch'],
      bonusScore:   25,
      severity:     'high',
    },

    // ── Conversation Hijacking ────────────────────────────────────────────────
    {
      id:           'conversation_hijacking',
      name:         'Conversation Hijacking',
      description:  'Financial request injected into a reply thread',
      requiredRules: ['conversation_hijacking_attempt'],
      optionalRules: ['bec_language_detected', 'reply_to_domain_mismatch', 'email_auth_failure'],
      bonusScore:   20,
      severity:     'high',
    },

    // ── Advanced Phishing with Obfuscation ────────────────────────────────────
    {
      id:           'advanced_obfuscated_phishing',
      name:         'Advanced Obfuscated Phishing',
      description:  'HTML/encoding obfuscation combined with link manipulation',
      requiredRules: ['html_obfuscation_phishing'],
      optionalRules: ['base64_encoded_url', 'html_link_text_mismatch', 'ip_based_url'],
      bonusScore:   20,
      severity:     'high',
    },

    // ── Malware + Social Engineering ─────────────────────────────────────────
    {
      id:           'malware_social_engineering',
      name:         'Malware Delivery via Social Engineering',
      description:  'Malicious attachment combined with urgent/BEC language',
      requiredRules: ['risky_attachment_detected'],
      optionalRules: ['bec_language_detected', 'urgent_phishing_language', 'first_contact_sender_risk'],
      bonusScore:   25,
      severity:     'critical',
    },

    // ── Infrastructure Abuse ──────────────────────────────────────────────────
    {
      id:           'infrastructure_abuse',
      name:         'Infrastructure Abuse',
      description:  'Suspicious received headers with auth failures',
      requiredRules: ['suspicious_received_headers', 'email_auth_failure'],
      optionalRules: ['typosquatting_domain', 'newly_registered_domain'],
      bonusScore:   15,
      severity:     'high',
    },
  ];

  /**
   * correlate() — scan all patterns against triggered rules.
   * Returns a CorrelationResult with matched patterns and total bonus score.
   */
  correlate(ctx: DetectionContext): CorrelationResult {
    try {
      return this.doCorrelate(ctx);
    } catch (err) {
      this.logger.error('CorrelationService.correlate failed', {
        error: err instanceof Error ? err.message : String(err),
      });
      return { patterns: [], bonusScore: 0, description: '' };
    }
  }

  private doCorrelate(ctx: DetectionContext): CorrelationResult {
    const matchedPatterns: string[] = [];
    let totalBonus = 0;
    const descriptions: string[] = [];

    for (const pattern of this.patterns) {
      if (!this.patternMatches(ctx, pattern)) continue;

      matchedPatterns.push(pattern.id);
      totalBonus += pattern.bonusScore;
      descriptions.push(`${pattern.name}: ${pattern.description} (+${pattern.bonusScore}pts)`);

      this.logger.log(`Correlation pattern matched: ${pattern.id}`, {
        emailId: ctx.parsedEmail.emailId,
        bonus:   pattern.bonusScore,
      });
    }

    return {
      patterns:    matchedPatterns,
      bonusScore:  Math.min(50, totalBonus), // cap bonus at 50 to prevent runaway scores
      description: descriptions.join(' | '),
    };
  }

  private patternMatches(ctx: DetectionContext, pattern: AttackPattern): boolean {
    // All required rules must be triggered
    const allRequired = pattern.requiredRules.every(r => ctx.isTriggered(r));
    if (!allRequired) return false;

    // If optional rules defined: at least one must be triggered
    if (pattern.optionalRules && pattern.optionalRules.length > 0) {
      const anyOptional = pattern.optionalRules.some(r => ctx.isTriggered(r));
      if (!anyOptional) return false;
    }

    return true;
  }

  /** Expose patterns for testing and DSL extension */
  getPatterns(): AttackPattern[] {
    return this.patterns;
  }

  /** Add a pattern at runtime (supports YAML-loaded patterns) */
  addPattern(pattern: AttackPattern): void {
    this.patterns.push(pattern);
  }
}
