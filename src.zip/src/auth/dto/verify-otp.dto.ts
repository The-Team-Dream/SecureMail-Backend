import { IsEmail, IsString, Length, Matches } from 'class-validator';

export class VerifyOtpDto {

  @IsEmail()
  email: string;

  @IsString()
  @Length(6, 6)
  @Matches(/^\d+$/, { message: 'OTP must be numeric' })
  otp: string;
}
